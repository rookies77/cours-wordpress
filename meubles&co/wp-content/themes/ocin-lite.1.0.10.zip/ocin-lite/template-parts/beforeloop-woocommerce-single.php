        <div id="content" class="col-md-12">
        	<?php
            if ( ! is_shop() && ! is_product() ) {
                echo '<div class="ql_background_padding">';
            }
            ?>

