jQuery(document).ready(function($) {
	var $destination = $("#customize-info .accordion-section-title");
 	$destination.prepend('<a style="width: 80%; margin: 10px auto; display: block; text-align: center;" href="https://www.quemalabs.com/theme/ocin/?utm_source=Ocin Lite%20Lite%20Theme&utm_medium=Pro%20Button&utm_campaign=Ocin Lite" class="button" target="_blank">{pro}</a>'.replace( '{pro}', topbtns.pro ) );
});

